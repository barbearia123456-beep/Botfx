'use strict';
const TFS={M1:1,M2:2,M3:3,M4:4,M5:5,M6:6,M10:10,M12:12,M15:15,M20:20,M30:30,H1:60,H2:120,H3:180,H4:240,H6:360,H8:480,H12:720,D1:1440,W1:10080,MN1:43200};
const SD=[['Forex Majors',[['EURUSD',1.085],['GBPUSD',1.27],['USDJPY',150],['USDCHF',.88],['AUDUSD',.65],['NZDUSD',.6],['USDCAD',1.36]]],
['Cruzados',[['EURGBP',.855],['EURJPY',163],['EURCHF',.955],['EURAUD',1.67],['EURNZD',1.81],['EURCAD',1.475],['GBPJPY',190],['GBPCHF',1.12],['GBPAUD',1.95],['GBPNZD',2.12],['GBPCAD',1.73],['AUDJPY',98],['AUDNZD',1.08],['AUDCAD',.885],['AUDCHF',.575],['NZDJPY',90],['NZDCAD',.82],['NZDCHF',.53],['CADJPY',110],['CADCHF',.65],['CHFJPY',170]]],
['Exóticos',[['USDSGD',1.35],['USDMXN',17],['USDZAR',18.5],['USDTRY',32],['USDNOK',10.6],['USDSEK',10.5],['USDHKD',7.8],['USDCNH',7.2]]],
['Metais e Energia',[['XAUUSD',2000],['XAGUSD',24],['USOIL',78]]],
['Índices',[['US30',38000],['NAS100',17500],['SPX500',5000],['GER40',17500],['UK100',7700]]],
['Cripto CFD',[['BTCUSD',65000],['ETHUSD',3300]]]];
const PIPO={XAUUSD:.1,XAGUSD:.01,USOIL:.01,US30:1,NAS100:1,SPX500:1,GER40:1,UK100:1,BTCUSD:1,ETHUSD:.1},SYMS={};
SD.forEach(g=>g[1].forEach(([n,p])=>SYMS[n]=[p,PIPO[n]||(n.includes('JPY')?.01:1e-4)]));
const NM={ma:'Médias móveis',rsi:'RSI',macd:'MACD',bb:'Bollinger Bands',breakout:'Breakout',scalp:'Scalping EMA+RSI',scalpbb:'Scalping Bollinger',sr:'Suporte/Resistência',pa:'Price Action',trend:'Seguidor de tendência',grid:'Grid automático'};
const ENVS=['Simulador','Demo','Real'],DEF={sl:30,tp:60,lot:.1,bal:10000,max:1};
const PRE={ma:{'EMA 9/21':{fast:9,slow:21},'EMA 20/50':{fast:20,slow:50},'EMA 50/200':{fast:50,slow:200}},
rsi:{'RSI14 30/70':{n:14,lo:30,hi:70},'RSI7 20/80':{n:7,lo:20,hi:80}},macd:{'MACD 12/26/9':{}},
bb:{'BB 20/2.0':{n:20,k:2},'BB 20/2.5':{n:20,k:2.5}},breakout:{'Canal 20':{n:20},'Canal 50':{n:50}},
scalp:{'EMA5/13+RSI7':{lo:30,hi:70},'Estrito':{lo:40,hi:60}},sr:{'S/R 30':{n:30},'S/R 60':{n:60}},
pa:{'Engolfo':{}},trend:{'EMA10/30 filtro 200':{f:10,s:30,t:200},'EMA20/50 filtro 100':{f:20,s:50,t:100}},scalpbb:{'BB10 + RSI5':{lo:25,hi:75},'BB10 estrito':{lo:20,hi:80}},grid:{'5+5 níveis, 20p':{n:5,step:20,dir:'both',sl:100,tp:20},'3 níveis só compra':{n:3,step:15,dir:'buy',sl:80,tp:15},'8 níveis só venda':{n:8,step:25,dir:'sell',sl:150,tp:25}}};
const $=s=>document.querySelector(s),v=id=>+$('#'+id).value;
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}},sv=(k,x)=>{try{localStorage.setItem(k,JSON.stringify(x))}catch(e){}};
let seed=42;const rnd=()=>(seed=seed*16807%2147483647)/2147483647;
function gen(sy){const[p0,pip]=SYMS[sy];seed=[...sy].reduce((a,c)=>a*31+c.charCodeAt(0),7)%2147483646+1;let p=p0,t=Math.floor(Date.now()/6e4)*60-20000*60;const a=[];
 for(let i=0;i<20000;i++){const o=p,w=p0*6e-4;p+=(rnd()-.5)*w*2+Math.sin(i/500)*w*.15;a.push({t:t+i*60,o,h:Math.max(o,p)+rnd()*w*.5,l:Math.min(o,p)-rnd()*w*.5,c:p})}return a}
function agg(a,m){if(m==1)return a;const r=[];let b=-1,c;for(const k of a){const x=Math.floor(k.t/(m*60));if(x!=b){b=x;c={t:k.t,o:k.o,h:k.h,l:k.l,c:k.c};r.push(c)}else{c.h=Math.max(c.h,k.h);c.l=Math.min(c.l,k.l);c.c=k.c}}return r}
/* indicadores */
const sma=(a,n)=>a.map((_,i)=>i<n-1?NaN:a.slice(i-n+1,i+1).reduce((x,y)=>x+y)/n);
const ema=(a,n)=>{const k=2/(n+1);let e=a[0];return a.map((x,i)=>e=i?x*k+e*(1-k):x)};
const rsi=(a,n=14)=>{let g=0,l=0;return a.map((x,i)=>{if(!i)return NaN;const d=x-a[i-1];if(i<=n){g+=Math.max(d,0)/n;l+=Math.max(-d,0)/n;return i<n?NaN:100-100/(1+g/(l||1e-9))}g=(g*(n-1)+Math.max(d,0))/n;l=(l*(n-1)+Math.max(-d,0))/n;return 100-100/(1+g/(l||1e-9))})};
const macd=a=>{const f=ema(a,12),s=ema(a,26),m=f.map((x,i)=>x-s[i]);return{m,sg:ema(m,9)}};
const bb=(a,n,k)=>{const m=sma(a,n);return a.map((_,i)=>{if(i<n-1)return[NaN,NaN,NaN];const s=a.slice(i-n+1,i+1),sd=Math.sqrt(s.reduce((x,y)=>x+(y-m[i])**2,0)/n);return[m[i]-k*sd,m[i],m[i]+k*sd]})};
/* estratégias: devolvem sinais +1 compra / -1 venda / 0 */
const X=(a,b,i)=>a[i-1]<=b[i-1]&&a[i]>b[i]?1:a[i-1]>=b[i-1]&&a[i]<b[i]?-1:0,C=d=>d.map(k=>k.c);
const S={
ma:(d,p)=>{const c=C(d),f=ema(c,p.fast),s=ema(c,p.slow);return c.map((_,i)=>i?X(f,s,i):0)},
rsi:(d,p)=>{const r=rsi(C(d),p.n);return r.map((x,i)=>i&&r[i-1]<p.lo&&x>=p.lo?1:i&&r[i-1]>p.hi&&x<=p.hi?-1:0)},
macd:d=>{const{m,sg}=macd(C(d));return m.map((_,i)=>i?X(m,sg,i):0)},
bb:(d,p)=>{const c=C(d),b=bb(c,p.n,p.k);return c.map((x,i)=>i<p.n?0:c[i-1]<b[i-1][0]&&x>=b[i][0]?1:c[i-1]>b[i-1][2]&&x<=b[i][2]?-1:0)},
breakout:(d,p)=>d.map((k,i)=>{if(i<p.n)return 0;const w=d.slice(i-p.n,i);return k.c>Math.max(...w.map(x=>x.h))?1:k.c<Math.min(...w.map(x=>x.l))?-1:0}),
scalp:(d,p)=>{const c=C(d),f=ema(c,5),s=ema(c,13),r=rsi(c,7);return c.map((_,i)=>{if(!i)return 0;const x=X(f,s,i);return x>0&&r[i]<p.hi?1:x<0&&r[i]>p.lo?-1:0})},
sr:(d,p)=>d.map((k,i)=>{if(i<p.n)return 0;const w=d.slice(i-p.n,i),lo=Math.min(...w.map(x=>x.l)),hi=Math.max(...w.map(x=>x.h)),t=(hi-lo)*.05;return k.l<=lo+t&&k.c>k.o?1:k.h>=hi-t&&k.c<k.o?-1:0}),
trend:(d,p)=>{const c=C(d),f=ema(c,p.f),q=ema(c,p.s),t=ema(c,p.t);return c.map((x,i)=>{if(!i)return 0;const z=X(f,q,i);return z>0&&x>t[i]?1:z<0&&x<t[i]?-1:0})},
scalpbb:(d,p)=>{const c=C(d),b=bb(c,10,1.5),r=rsi(c,5);return c.map((x,i)=>i<10?0:x<b[i][0]&&r[i]<p.lo?1:x>b[i][2]&&r[i]>p.hi?-1:0)},
pa:d=>d.map((k,i)=>{if(!i)return 0;const q=d[i-1];return q.c<q.o&&k.c>k.o&&k.c>=q.o&&k.o<=q.c?1:q.c>q.o&&k.c<k.o&&k.c<=q.o&&k.o>=q.c?-1:0})};
/* backtest: entrada no fechamento do sinal, SL/TP verificados nas velas seguintes (sem spread/slippage) */
function bt(d,name,p,sy){const pip=SYMS[sy][1],tr=[],L=[];let bal=p.bal,pos=[],pk=bal,dd=0;const eq=[bal];
 const sg=name=='grid'?null:S[name](d,p),an=d[Math.min(60,d.length-1)].c;
 if(!sg)for(let j=1;j<=p.n;j++){if(p.dir!='sell')L.push({pr:an-j*p.step*pip,s:1});if(p.dir!='buy')L.push({pr:an+j*p.step*pip,s:-1})}
 const open=(k,pr,s,lv)=>pos.push({p:pr,s,lv,sl:pr-s*p.sl*pip,tp:pr+s*p.tp*pip});
 for(let i=60;i<d.length;i++){const k=d[i];
  pos=pos.filter(x=>{let e=null;if(x.s>0){if(k.l<=x.sl)e=x.sl;else if(k.h>=x.tp)e=x.tp}else{if(k.h>=x.sl)e=x.sl;else if(k.l<=x.tp)e=x.tp}
   if(e==null)return true;const pl=(e-x.p)*x.s/pip*10*p.lot;bal+=pl;tr.push({t:k.t,s:x.s,pl});if(x.lv)x.lv.cl=true;return false});
  if(sg){if(sg[i]&&pos.length<(p.max||1))open(k,k.c,sg[i])}
  else L.forEach(l=>{if(l.cl&&(l.s>0?k.c>l.pr:k.c<l.pr)){l.cl=false;l.o=false}if(!l.o&&(l.s>0?k.l<=l.pr:k.h>=l.pr)){l.o=true;open(k,l.pr,l.s,l)}});
  eq.push(bal);pk=Math.max(pk,bal);dd=Math.max(dd,pk-bal)}
 const w=tr.filter(t=>t.pl>0),gp=w.reduce((a,t)=>a+t.pl,0),gl=-tr.filter(t=>t.pl<=0).reduce((a,t)=>a+t.pl,0);
 return{n:tr.length,wr:tr.length?w.length/tr.length*100:0,net:bal-p.bal,pf:gl?gp/gl:gp?Infinity:0,dd,bal,eq,tr}}
if(typeof module!='undefined')module.exports={bt,S,gen,agg,SYMS};
if(typeof document!='undefined')(function(){
let env=0,sym='EURUSD',tf='M15',N=80,off=0,cur='trade',cnt=0;const _M={},SRC={},M1=new Proxy(_M,{get:(o,k)=>o[k]||(typeof k=='string'&&SYMS[k]?(SRC[k]='SINTÉTICO',o[k]=gen(k)):undefined),set:(o,k,x)=>(o[k]=x,true)});

const acc=[0,1,2].map(e=>ld('fx_a'+e,{bal:10000,pos:[],hist:[]})),save=()=>{acc.forEach((a,e)=>sv('fx_a'+e,a));sv('fx_bots',bots)};
let bots=ld('fx_bots',[]),srv=ld('fx_srv',[]);const pip=s=>SYMS[s||sym][1],px=s=>M1[s||sym].at(-1).c,fx=(n,s)=>n.toFixed(pip(s)<.01?5:pip(s)<1?2:0);
const connected=e=>e==0; /* Demo/Real só ficam ativos quando um adaptador real de corretora existir */
const pl=(x,pr)=>(pr-x.p)*x.s/pip(x.sym)*10*x.lot;
function canTrade(){if(connected(env))return true;alert('Conta '+ENVS[env]+' sem conexão com corretora. Veja a aba Corretoras.');return false}
function closePos(id,pr){const a=acc[env],i=a.pos.findIndex(x=>x.id==id);if(i<0)return;const x=a.pos[i],r=pl(x,pr),g=bots.find(q=>'bot'+q.id==x.by);if(g&&g.lv&&g.lv[x.li])g.lv[x.li].cl=true;a.bal+=r;a.hist.push({t:Date.now(),sym:x.sym,s:x.s,lot:x.lot,p:x.p,c:pr,pl:r,by:x.by||'manual'});a.pos.splice(i,1)}
function open(s,sy,lot,sl,tp,by,li){const a=acc[0],p=px(sy),q=pip(sy);a.pos.push({id:Date.now()+Math.random(),sym:sy,s,p,lot,sl:sl?p-s*sl*q:0,tp:tp?p+s*tp*q:0,by,li})}
window.ord=s=>{if(!canTrade())return;open(s,sym,v('lot'),v('osl'),v('otp'),'manual');save();refL()};
window.cls=id=>{closePos(id,px(acc[env].pos.find(x=>x.id==id).sym));save();refL()};
/* UI */
$('#envs').innerHTML=ENVS.map((n,i)=>`<button data-e=${i}>${n}</button>`).join('');
$('#sym').innerHTML=SD.map(g=>`<optgroup label="${g[0]}">${g[1].map(q=>`<option>${q[0]}</option>`).join('')}</optgroup>`).join('');
$('#tfs').innerHTML=Object.keys(TFS).map(t=>`<button data-t=${t}>${t}</button>`).join('');
const NAV={trade:'Operar',strat:'Estratégias',bots:'Robôs',brk:'Corretoras',hist:'Histórico'};
$('#nv').innerHTML=Object.entries(NAV).map(([k,n])=>`<button data-p=${k}>${n}</button>`).join('');
function mark(){document.querySelectorAll('#envs button').forEach(b=>b.classList.toggle('on',b.dataset.e==env));document.querySelectorAll('#tfs button').forEach(b=>b.classList.toggle('on',b.dataset.t==tf));document.querySelectorAll('#nv button').forEach(b=>b.classList.toggle('on',b.dataset.p==cur))}
$('#envs').onclick=e=>{if(e.target.dataset.e){env=+e.target.dataset.e;mark();nav(cur)}};
$('#tfs').onclick=e=>{if(e.target.dataset.t){tf=e.target.dataset.t;off=0;mark();draw()}};
$('#nv').onclick=e=>{if(e.target.dataset.p)nav(e.target.dataset.p)};
$('#sym').onchange=e=>{sym=e.target.value;off=0;draw();nav(cur)};
$('#iE').onchange=$('#iB').onchange=draw;$('#zi').onclick=()=>{N=Math.max(20,N-15);draw()};$('#zo').onclick=()=>{N=Math.min(300,N+15);draw()};$('#gl').onclick=()=>{off=0;draw()};
const cv=$('#ch');let sx=null;cv.onpointerdown=e=>sx=e.clientX;cv.onpointerup=cv.onpointerleave=()=>sx=null;
cv.onpointermove=e=>{if(sx==null)return;const k=Math.round((e.clientX-sx)/(cv.clientWidth/N));if(k){off=Math.max(0,off+k);sx=e.clientX;draw()}};
let ctype='c';$('#ct').onclick=()=>{ctype=ctype=='c'?'l':'c';$('#ct').textContent=ctype=='c'?'Velas':'Linha';draw()};
function draw(){const r=devicePixelRatio||1,w=cv.width=cv.clientWidth*r,h=cv.height=cv.clientHeight*r,x=cv.getContext('2d');
 const d=agg(M1[sym],TFS[tf]),e=Math.max(Math.min(N,d.length),d.length-off),s=Math.max(0,e-N),vw=d.slice(s,e);if(!vw.length)return;
 const c=C(d),H1=h*.78,AX=54*r;let hi=-1e9,lo=1e9;vw.forEach(k=>{hi=Math.max(hi,k.h);lo=Math.min(lo,k.l)});const pd=(hi-lo)*.1||pip();hi+=pd;lo-=pd;
 const cw=(w-AX)/N,Y=p=>H1-(p-lo)/(hi-lo)*H1,Xc=i=>(i-s)*cw+cw/2,G=w-AX;
 const bg=x.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#10201b');bg.addColorStop(1,'#060a09');x.fillStyle=bg;x.fillRect(0,0,w,h);x.font=10*r+'px monospace';x.lineWidth=1;
 for(let i=1;i<6;i++){const p=lo+(hi-lo)*i/6;x.strokeStyle='#18261f';x.beginPath();x.moveTo(0,Y(p));x.lineTo(G,Y(p));x.stroke();x.fillStyle='#6f877b';x.fillText(fx(p),G+4*r,Y(p)+3*r)}
 for(let i=s+4;i<e;i+=Math.max(1,Math.ceil(N/5))){const t=new Date(d[i].t*1000);x.strokeStyle='#121e19';x.beginPath();x.moveTo(Xc(i),0);x.lineTo(Xc(i),H1);x.stroke();x.fillStyle='#6f877b';x.fillText(TFS[tf]>=1440?t.toLocaleDateString([],{day:'2-digit',month:'short'}):t.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}),Xc(i)-14*r,H1-4*r)}
 if(ctype=='l'){x.beginPath();vw.forEach((k,i)=>{const X0=Xc(s+i);i?x.lineTo(X0,Y(k.c)):x.moveTo(X0,Y(k.c))});x.strokeStyle='#e8b84a';x.lineWidth=2*r;x.stroke();x.lineTo(Xc(e-1),H1);x.lineTo(Xc(s),H1);const a=x.createLinearGradient(0,0,0,H1);a.addColorStop(0,'rgba(232,184,74,.35)');a.addColorStop(1,'rgba(232,184,74,0)');x.fillStyle=a;x.fill()}
 else vw.forEach((k,i)=>{const X0=Xc(s+i),col=k.c>=k.o?'#2fd39a':'#ff6b6b';x.strokeStyle=x.fillStyle=col;x.lineWidth=Math.max(1,r);x.beginPath();x.moveTo(X0,Y(k.h));x.lineTo(X0,Y(k.l));x.stroke();x.shadowColor=col;x.shadowBlur=5*r;x.fillRect(X0-cw*.36,Math.min(Y(k.o),Y(k.c)),cw*.72,Math.max(r,Math.abs(Y(k.o)-Y(k.c))));x.shadowBlur=0});
 const ln=(a,col)=>{x.strokeStyle=col;x.lineWidth=1.6*r;x.beginPath();let on=0;for(let i=s;i<e;i++){if(isNaN(a[i]))continue;on?x.lineTo(Xc(i),Y(a[i])):x.moveTo(Xc(i),Y(a[i]));on=1}x.stroke()};
 if($('#iE').checked){ln(ema(c,20),'#e8b84a');ln(ema(c,50),'#4da3ff')}
 if($('#iB').checked){const b=bb(c,20,2);[0,1,2].forEach(j=>ln(b.map(q=>q[j]),'#b388ff'))}
 const dl=(p,col,da)=>{x.setLineDash(da.map(z=>z*r));x.strokeStyle=col;x.beginPath();x.moveTo(0,Y(p));x.lineTo(G,Y(p));x.stroke();x.setLineDash([])};
 if(env==0){acc[0].pos.filter(q=>q.sym==sym).forEach(q=>{const col=q.s>0?'#2fd39a':'#ff6b6b';dl(q.p,col,[6,4]);x.fillStyle=col;x.fillText((q.s>0?'C ':'V ')+q.lot+'  '+fm(pl(q,px(sym))),6*r,Y(q.p)-4*r);[q.sl,q.tp].forEach(z=>z&&dl(z,'#8aa095',[2,4]))});
  bots.filter(b=>b.sym==sym&&b.lv).forEach(b=>b.lv.forEach(l=>dl(l.pr,'rgba(232,184,74,.4)',[1,5])))}
 const lp=px(),up=lp>=d.at(-1).o,col=up?'#2fd39a':'#ff6b6b';dl(lp,col,[3,3]);x.fillStyle=col;x.fillRect(G,Y(lp)-8*r,AX,16*r);x.fillStyle='#04140e';x.fillText(fx(lp),G+3*r,Y(lp)+4*r);
 const R=rsi(c,14),y0=H1+8*r,hh=h-y0-4*r,RY=q=>y0+(100-q)/100*hh;x.strokeStyle='#18261f';x.lineWidth=1;[30,70].forEach(l=>{x.beginPath();x.moveTo(0,RY(l));x.lineTo(G,RY(l));x.stroke();x.fillStyle='#6f877b';x.fillText(l,G+4*r,RY(l)+3*r)});
 x.beginPath();x.strokeStyle='#b388ff';x.lineWidth=1.5*r;let on=0;for(let i=s;i<e;i++){if(isNaN(R[i]))continue;on?x.lineTo(Xc(i),RY(R[i])):x.moveTo(Xc(i),RY(R[i]));on=1}x.stroke();x.fillStyle='#b388ff';x.fillText('RSI 14  '+R.at(-1).toFixed(1),6*r,y0+11*r);
 const k=d.at(-1);$('#info').textContent=`${sym} ${tf}  O ${fx(k.o)}  H ${fx(k.h)}  L ${fx(k.l)}  C ${fx(k.c)}`;$('#src').textContent='Dados: '+SRC[sym];const q=$('#cur');if(q)q.textContent='aplica em '+sym+' · '+tf}
/* painéis */
const P={},fm=n=>(n>=0?'+':'')+n.toFixed(2);
const stats=h=>{const w=h.filter(t=>t.pl>0).length;return`${h.length} ops · acerto ${h.length?(w/h.length*100).toFixed(1):0}% · líquido ${fm(h.reduce((a,t)=>a+t.pl,0))}`};
const SF=()=>`<div class=card><b>Estratégias automáticas (robô)</b> <small id=cur class=mu></small><div class=row><select id=sn>${Object.keys(PRE).map(n=>`<option value=${n}>${NM[n]}</option>`).join('')}</select><select id=sp></select></div>
<div class=row><label class=mu>Lote<input id=a_lot type=number step=.01 value=.1></label><label class=mu>SL pips<input id=a_sl type=number value=30></label><label class=mu>TP pips<input id=a_tp type=number value=60></label><label class=mu>Máx. pos.<input id=a_max type=number value=1></label></div>
<textarea id=pj aria-label="Parâmetros da estratégia"></textarea>
<div class=row><button class=p id=bb2>▶ Aplicar no robô</button><button id=bb1>Backtest</button></div>
<div class=row><label class=mu>Importar CSV M1 para ${sym}<input type=file id=csv accept=".csv,.txt"></label></div><div id=res class=mu>Backtest usa ${sym} · ${SRC[sym]}.</div></div>`;
P.trade=()=>(connected(env)?`<div class=card><b>Operação manual · ${sym}</b><div class=row><input id=lot type=number step=.01 value=.1 aria-label=Lote><input id=osl type=number placeholder="SL pips"><input id=otp type=number placeholder="TP pips"></div><div class=row><button class=s onclick="ord(-1)">VENDER</button><button class=b onclick="ord(1)">COMPRAR</button></div><small class=mu>Sem spread/comissão/slippage. P/L aprox. US$10/pip/lote.</small></div>`:`<div class="card warn">Conta ${ENVS[env]} <b>não conectada</b>: nenhuma ordem pode ser enviada. Veja Corretoras.</div>`)+SF()+'<div id=bots></div><div id=live></div>';
P.strat=()=>SF()+'<div id=bots></div>';P.bots=()=>'<div id=bots></div><div id=live></div>';
const live=()=>`<div class=card><b>Posições abertas</b><table>${acc[env].pos.map(x=>{const r=pl(x,px(x.sym));return`<tr><td>${x.sym}</td><td>${x.s>0?'C':'V'} ${x.lot}</td><td>${fx(x.p,x.sym)}</td><td class="${r>=0?'up':'dn'}">${fm(r)}</td><td class=mu>${(x.by||'').replace('bot','🤖')}</td><td><button onclick="cls(${x.id})">×</button></td></tr>`}).join('')||'<tr><td class=mu>Sem posições.</td></tr>'}</table></div>`;
const botsHTML=()=>`<div class=card><b>Robôs automáticos</b>${bots.map(b=>{const h=acc[0].hist.filter(t=>t.by=='bot'+b.id),f=acc[0].pos.filter(x=>x.by=='bot'+b.id),r=h.reduce((a,t)=>a+t.pl,0)+f.reduce((a,x)=>a+pl(x,px(x.sym)),0);return`<div class=row><span><b>${NM[b.n]}</b> ${b.sym} ${b.tf}<br><small class=mu>${b.st=='run'?'● rodando':'⏸ pausado'} · ${h.length} ops · ${f.length} abertas<br>${b.lv?b.lv.filter(l=>l.o).length+'/'+b.lv.length+' níveis ativos':(b.an||0)+' velas analisadas · sinal: '+(b.sg>0?'compra':b.sg<0?'venda':'aguardando')}</small></span><b class="${r>=0?'up':'dn'}">${fm(r)}</b><button onclick="bot(${b.id},'run')">▶</button><button onclick="bot(${b.id},'pause')">⏸</button><button onclick="bot(${b.id},'stop')">■</button></div>`}).join('')||'<div class=mu>Nenhum robô. Escolha a estratégia e toque em “Aplicar no robô”.</div>'}</div>`;
function refL(){const l=$('#live'),b=$('#bots');if(l)l.innerHTML=live();if(b)b.innerHTML=botsHTML()}
window.bot=(id,st)=>{const b=bots.find(x=>x.id==id);if(!b)return;if(st=='stop'){acc[0].pos.filter(x=>x.by=='bot'+id).forEach(x=>env0close(x,px(x.sym)));bots=bots.filter(x=>x!=b)}else b.st=st;save();refL()};
function fillP(){const n=$('#sn').value,q=PRE[n][$('#sp').value];$('#a_sl').value=q.sl||30;$('#a_tp').value=q.tp||60;$('#pj').value=JSON.stringify(q)}
function bindS(){if(!$('#sn'))return;const f=()=>{$('#sp').innerHTML=Object.keys(PRE[$('#sn').value]).map(k=>`<option>${k}</option>`).join('');fillP()};$('#sn').onchange=f;$('#sp').onchange=fillP;f();
 const get=()=>{try{return{...DEF,...JSON.parse($('#pj').value),lot:v('a_lot'),sl:v('a_sl'),tp:v('a_tp'),max:v('a_max')}}catch(e){alert('Parâmetros JSON inválidos');return null}};
 $('#bb1').onclick=()=>{const p=get();if(!p)return;const r=bt(agg(M1[sym],TFS[tf]),$('#sn').value,p,sym);
  $('#res').innerHTML=`<b>${r.n}</b> ops · acerto <b>${r.wr.toFixed(1)}%</b> · líquido <b class="${r.net>=0?'up':'dn'}">${fm(r.net)}</b> · PF ${isFinite(r.pf)?r.pf.toFixed(2):'∞'} · DD ${r.dd.toFixed(2)}<canvas id=eq></canvas><small class=mu>${sym} ${tf} · dados ${SRC[sym]}${SRC[sym]=='SINTÉTICO'?' (gerados, não são mercado real)':''}. Sem spread/slippage.</small>`;
  const q=$('#eq'),x=q.getContext('2d'),W=q.width=q.clientWidth,Hh=q.height=q.clientHeight,mn=Math.min(...r.eq),mx=Math.max(...r.eq);x.strokeStyle='#e8b84a';x.beginPath();r.eq.forEach((y,i)=>{const X0=i/(r.eq.length-1)*W,Y0=Hh-(y-mn)/((mx-mn)||1)*Hh;i?x.lineTo(X0,Y0):x.moveTo(X0,Y0)});x.stroke()};
 $('#bb2').onclick=()=>{const p=get();if(!p)return;if(env!=0)return alert('Robôs rodam na conta Simulador. Troque para Simulador.');const n=$('#sn').value,b={id:Date.now(),n,sym,tf,p,st:'run',last:agg(M1[sym],TFS[tf]).length};
  if(n=='grid'){const an=px(),q=pip();b.lv=[];for(let j=1;j<=p.n;j++){if(p.dir!='sell')b.lv.push({pr:an-j*p.step*q,s:1});if(p.dir!='buy')b.lv.push({pr:an+j*p.step*q,s:-1})}}
  if(!b.lv){const z=S[n](agg(M1[sym],TFS[tf]).slice(-1500,-1),p).slice(-30).reverse().find(q=>q);if(z)open(z,sym,p.lot,p.sl,p.tp,'bot'+b.id)}bots.push(b);save();refL()};
 $('#csv').onchange=async e=>{const t=await e.target.files[0].text(),a=[];for(const l of t.split(/\r?\n/)){const c=l.split(/[,;\t]/);if(c.length<5)continue;let ts=isNaN(+c[0])?Date.parse(c[0])/1000:+c[0];if(isNaN(ts))continue;a.push({t:ts,o:+c[1],h:+c[2],l:+c[3],c:+c[4]})}
  if(a.length<200)return alert('CSV inválido ou com poucas velas (mín. 200).');M1[sym]=a;SRC[sym]='CSV importado';draw();nav(cur)}}
P.hist=()=>{const h=acc[env].hist;return`<div class=card><b>${ENVS[env]}</b><br>${stats(h)}</div><div class=card><table>${h.slice().reverse().map(t=>`<tr><td>${new Date(t.t).toLocaleString()}</td><td>${t.sym}</td><td>${t.s>0?'C':'V'}</td><td class="${t.pl>=0?'up':'dn'}">${fm(t.pl)}</td><td class=mu>${t.by}</td></tr>`).join('')||'<tr><td class=mu>Sem histórico.</td></tr>'}</table></div>`};
const BRK=[['Exness','MT5/MT4'],['XM','MT5/MT4'],['IC Markets','MT5/MT4/cTrader'],['Pepperstone','MT5/MT4/cTrader'],['RoboForex','MT5/MT4/cTrader'],['OANDA','API REST v20']];
P.brk=()=>`<div class=card><input id=q placeholder="Buscar corretora ou servidor" style="width:100%"><div id=bl></div></div>
 <div class=card><div class=row><select id=bk>${BRK.map(b=>`<option>${b[0]}</option>`)}</select><select id=bt><option>Demo</option><option>Real</option></select></div>
 <div class=row><input id=bs list=sl placeholder="Servidor (ex.: nome exibido no seu MT5)"><datalist id=sl>${srv.map(s=>`<option value="${s.name}">`).join('')}</datalist></div>
 <div class=row><input id=lg placeholder=Login><input id=pw type=password placeholder=Senha autocomplete=off></div>
 <div class=row><button id=ad>Salvar servidor</button><button class=p id=cn>Conectar</button></div><div id=cm class=mu></div></div>`;
const bindB=()=>{const r=()=>{const q=$('#q').value.toLowerCase();$('#bl').innerHTML='<table>'+BRK.filter(b=>b[0].toLowerCase().includes(q)).map(b=>`<tr><td>${b[0]}</td><td class=mu>${b[1]}</td></tr>`).join('')+srv.filter(s=>(s.b+s.name).toLowerCase().includes(q)).map(s=>`<tr><td>${s.b}</td><td>${s.name}</td><td class=mu>${s.type}</td></tr>`).join('')+'</table>'};$('#q').oninput=r;r();
 $('#ad').onclick=()=>{const n=$('#bs').value.trim();if(!n)return;srv.push({b:$('#bk').value,name:n,type:$('#bt').value});sv('fx_srv',srv);nav('brk')};
 $('#cn').onclick=()=>{$('#cm').textContent='Conexão não disponível: MT4/MT5 usam protocolo proprietário sem API pública para apps. É preciso um adaptador (MetaApi, cTrader Open API, OANDA v20 ou um backend próprio com a biblioteca MetaTrader5). Senha não foi armazenada nem enviada.'}};
const BIND={trade:bindS,strat:bindS,brk:bindB};
function nav(p){cur=p;$('#pn').innerHTML=P[p]();BIND[p]&&BIND[p]();mark();refL()}
/* ticks e motor de robôs */
let TPC=1;$('#spd').onchange=e=>TPC=+e.target.value;
function acctUp(){const a=acc[env],f=a.pos.reduce((t,x)=>t+pl(x,px(x.sym)),0);$('#acct').innerHTML=`<span>Saldo <b>${a.bal.toFixed(2)}</b></span><span>Equity <b>${(a.bal+f).toFixed(2)}</b></span><span>Flutuante <b class="${f>=0?'up':'dn'}">${fm(f)}</b></span><span>${a.pos.length} pos.</span>`}
function env0close(x,pr){const e=env;env=0;closePos(x.id,pr);env=e}
setInterval(()=>{cnt++;for(const s in M1){const a=M1[s],k=a.at(-1),sg=SYMS[s][0]*1.2e-3/Math.sqrt(TPC),p=k.c+(rnd()-.5)*sg;k.c=p;k.h=Math.max(k.h,p);k.l=Math.min(k.l,p);if(cnt%TPC==0)a.push({t:k.t+60,o:p,h:p,l:p,c:p})}
 const a=acc[0];a.pos.slice().forEach(x=>{const p=px(x.sym);if(x.sl&&(x.s>0?p<=x.sl:p>=x.sl))env0close(x,x.sl);else if(x.tp&&(x.s>0?p>=x.tp:p<=x.tp))env0close(x,x.tp)});
 bots.filter(b=>b.st=='run').forEach(b=>{if(b.lv){const p=px(b.sym);b.lv.forEach((l,i)=>{if(l.cl&&(l.s>0?p>l.pr:p<l.pr)){l.cl=false;l.o=false}if(!l.o&&(l.s>0?p<=l.pr:p>=l.pr)){l.o=true;open(l.s,b.sym,b.p.lot,b.p.sl,b.p.tp,'bot'+b.id,i)}})}
  else if(cnt%TPC==0){const d=agg(M1[b.sym],TFS[b.tf]);if(d.length==b.last)return;b.last=d.length;const z=S[b.n](d.slice(-1500,-1),b.p).at(-1);b.an=(b.an||0)+1;b.sg=z;if(z&&a.pos.filter(x=>x.by=='bot'+b.id).length<(b.p.max||1))open(z,b.sym,b.p.lot,b.p.sl,b.p.tp,'bot'+b.id)}});
 if(cnt%5==0)save();$('#px').textContent=fx(px());acctUp();draw();refL()},1000);
if('serviceWorker'in navigator)navigator.serviceWorker.register('service-worker.js').catch(()=>{});
mark();nav('trade');draw();acctUp();$('#px').textContent=fx(px());
})();
