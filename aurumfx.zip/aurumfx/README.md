# Aurum FX Terminal
Terminal Forex (PWA + Capacitor/Android). `npm install && npm run android`. Teste do motor: `npm test`.
## Funciona
Gráfico candlestick (21 timeframes, EMA, Bollinger, RSI/MACD), Simulador com ordens/SL/TP/histórico, backtest (MA, RSI, MACD, Bollinger, Breakout, Scalping, S/R, Price Action, Grid), robôs no Simulador, importação CSV M1, busca de corretoras/servidores, contas separadas.
## NÃO funciona ainda (honesto)
- Dados de mercado reais: o padrão é série SINTÉTICA rotulada. Use CSV M1 ou implemente um provedor.
- Demo/Real: MT4/MT5 não têm API pública para apps. Integração exige MetaApi, cTrader Open API, OANDA v20 ou backend próprio. Ordens ficam bloqueadas nessas contas.
- Robô em segundo plano Android (Foreground Service nativo): não implementado (robôs rodam com o app aberto).
- Código em um único app.js; separar em módulos é a próxima etapa.
