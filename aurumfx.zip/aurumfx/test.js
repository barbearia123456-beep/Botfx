const{bt,S,gen,agg}=require('./app.js');const d=agg(gen('EURUSD'),15);
for(const n of Object.keys(S).concat('grid')){const r=bt(d,n,{sl:30,tp:60,lot:.1,bal:10000,max:1,f:10,s:30,t:200,fast:9,slow:21,n:20,lo:30,hi:70,k:2,step:20,dir:'both'},'EURUSD');console.log(n,r.n,r.wr.toFixed(1)+'%',r.net.toFixed(2))}
